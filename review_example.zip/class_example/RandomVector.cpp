#include <cstdlib>
#include <vector>
#include "RandomVector.hpp"

RandomVector::RandomVector(int size){
  this->size = size;
}

std::vector<double> RandomVector::make_random(double range){
  std::vector<double>output(size, 0.0);
  for (int i = 0; i < size; ++i){
    output[i] = range*((double) std::rand()) / RAND_MAX;
  }
  return output;
}