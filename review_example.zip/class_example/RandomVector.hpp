#pragma once

class RandomVector{
  int size;
public:
  RandomVector(int size_);
  std::vector<double> make_random(double range);
};