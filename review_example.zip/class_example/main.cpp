#include <fstream>
#include <iostream>
#include <vector>
#include "RandomVector.hpp"

int main() {
  std::ifstream f("input.txt");
  int input_length;
  double range;

  f >> input_length >> range;
  f.close();

  std::cout << "Hello World!\n";
  RandomVector rv(input_length);
  std::vector<double> output = rv.make_random(range);

  for (int i = 0; i < output.size(); ++i){
    std::cout << output[i] << std::endl;
  }

  
}